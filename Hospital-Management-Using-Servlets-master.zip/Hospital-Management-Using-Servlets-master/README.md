# Hospital-Management-Using-Servlets
It is an web application for Hospital management using JAVA Servlets and Tomcat server. Database is maintained using MySQL.
